import logo from './logo.svg';
import './App.css';
import Container from './app/layout/container/container';
import Loader from './app/layout/loader/loader';
function App() {
  return (
    <Container></Container>
  );
}

export default App;
